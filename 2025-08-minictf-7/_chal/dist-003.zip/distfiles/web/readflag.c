#include <stdio.h>

int main() {
    puts("flag{DUMMY}");
    return 0;
}